package game.BlackJack;

import java.util.List;

public class DealerDTO {
    private List<CardDTO> dealerCards;  // 딜러 카드 목록
    private int dealerScore;            // 딜러 점수
    private boolean canDrawCard;        // 딜러가 카드를 뽑을 수 있는지 여부

    // 생성자
    public DealerDTO(List<CardDTO> dealerCards, int dealerScore, boolean canDrawCard) {
        this.dealerCards = dealerCards;
        this.dealerScore = dealerScore;
        this.canDrawCard = canDrawCard;
    }

    // Getter 및 Setter
    public List<CardDTO> getDealerCards() {
        return dealerCards;
    }

    public void setDealerCards(List<CardDTO> dealerCards) {
        this.dealerCards = dealerCards;
    }

    public int getDealerScore() {
        return dealerScore;
    }

    public void setDealerScore(int dealerScore) {
        this.dealerScore = dealerScore;
    }

    public boolean isCanDrawCard() {
        return canDrawCard;
    }

    public void setCanDrawCard(boolean canDrawCard) {
        this.canDrawCard = canDrawCard;
    }
}
