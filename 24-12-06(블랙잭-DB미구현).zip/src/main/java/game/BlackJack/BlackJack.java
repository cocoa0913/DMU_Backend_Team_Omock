package game.BlackJack;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/blackjack")
public class BlackJack extends HttpServlet {

    private GameDAO gameDAO;

    @Override
    public void init() throws ServletException {
        gameDAO = new GameDAO();  // DAO 인스턴스 생성
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 세션에서 gameDTO 가져오기
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        // 게임이 종료되었거나, gameDTO가 없다면 게임을 새로 시작
        if (gameDTO == null || gameDTO.isGameOver()) {
            gameDTO = gameDAO.startGame();  // 새 게임 시작
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 세션에서 gameDTO 가져오기
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        // 게임이 없으면 새로 시작
        if (gameDTO == null) {
            gameDTO = gameDAO.startGame();
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        String action = request.getParameter("action");

        if ("hit".equals(action)) {
            // 플레이어가 카드를 한 장 더 받음
            gameDTO = gameDAO.hitPlayer(gameDTO);
        } else if ("result".equals(action)) {
            // 딜러가 카드를 뽑음
            gameDTO = gameDAO.dealerTurn(gameDTO);
        } else if ("restart".equals(action)) {
            // 새 게임 시작
            gameDTO = gameDAO.startGame();
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        session.setAttribute("game", gameDTO);  // 세션에 저장

        // 승패 결과를 판별하여 추가
        String winner = gameDAO.determineWinner(gameDTO);
        request.setAttribute("winner", winner);

        // 플레이어 점수가 21을 초과하면 히트 버튼을 숨길 수 있도록 처리
        boolean isPlayerScoreOver21 = gameDTO.getPlayerScore() >= 21;
        request.setAttribute("isPlayerScoreOver21", isPlayerScoreOver21);

        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }
}

