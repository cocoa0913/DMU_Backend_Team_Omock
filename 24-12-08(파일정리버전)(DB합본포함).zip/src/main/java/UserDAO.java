import java.sql.*;

public class UserDAO {
    private Connection conn;

    // DAO 생성자
    public UserDAO(Connection conn) {
        this.conn = conn;
    }

    // ID 중복 확인
    public boolean isIdExists(String id) throws SQLException {
        String query = "SELECT COUNT(*) FROM users WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        }
    }

    // 닉네임 중복 확인
    public boolean isNicknameExists(String nickname) throws SQLException {
        String query = "SELECT COUNT(*) FROM users WHERE nickname = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nickname);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        }
    }

    // 사용자 추가
    public int addUser(UserDTO user) throws SQLException {
        String query = "INSERT INTO users (id, password, nickname) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getId());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getNickname());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
            return -1;
        }
    }

    // 기본 아이템 추가
    public void addDefaultItem(int userCode) throws SQLException {
        String query = "INSERT INTO user_items (user_code, item_code, acquired_date) VALUES (?, ?, NOW())";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userCode);
            stmt.setInt(2, 1); // 기본 아이템 코드
            stmt.executeUpdate();
        }
    }

    public boolean updateNickname(int userCode, String newNickname) throws SQLException {
        String query = "UPDATE users SET nickname = ? WHERE user_code = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newNickname);
            stmt.setInt(2, userCode);
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        }
    }

    public boolean updateIcon(int userCode, int iconCode) throws SQLException {
        String query = "UPDATE users SET icon_code = ? WHERE user_code = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, iconCode);
            stmt.setInt(2, userCode);
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        }
    }

    public int createRoom(RoomDTO room) throws SQLException {
        String query = "INSERT INTO rooms (room_title, room_password, owner_code, is_private) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, room.getRoomTitle());
            stmt.setString(2, room.getRoomPassword() != null && !room.getRoomPassword().isEmpty() ? room.getRoomPassword() : null);
            stmt.setInt(3, room.getOwnerCode());
            stmt.setBoolean(4, room.isPrivate());
            stmt.executeUpdate();

            // 생성된 방 ID 가져오기
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }
        return 0; // 방 ID가 생성되지 않았을 경우
    }

    public boolean deleteFriend(int userCode, int friendCode) throws SQLException {
        String query = "DELETE FROM friends WHERE user_code = ? AND friend_code = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userCode);
            stmt.setInt(2, friendCode);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // 삭제 성공 여부 반환
        }
    }

    public String getNicknameByUserCode(int userCode) throws SQLException {
        String query = "SELECT nickname FROM users WHERE user_code = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userCode);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("nickname");
            }
        }
        return null; // 사용자 코드에 해당하는 닉네임이 없으면 null 반환
    }

    // 사용자 닉네임으로 user_code를 가져오는 메서드
    public int getUserCodeByNickname(String nickname) throws SQLException {
        String query = "SELECT user_code FROM users WHERE nickname = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nickname);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("user_code");
            }
        }
        return -1; // 사용자 닉네임에 해당하는 user_code가 없으면 -1 반환
    }

    // 친구 관계가 이미 존재하는지 확인하는 메서드
    public boolean isAlreadyFriend(int userCode, int friendCode) throws SQLException {
        String query = "SELECT * FROM friends WHERE user_code = ? AND friend_code = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userCode);
            stmt.setInt(2, friendCode);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // 이미 친구 관계가 존재하면 true 반환
        }
    }

    // 친구 추가 시 상태를 바로 'accepted'로 변경
    public void addFriend(int userCode, int friendCode) throws SQLException {
        String query = "INSERT INTO friends (user_code, friend_code, status) VALUES (?, ?, 'accepted')";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userCode);
            stmt.setInt(2, friendCode);
            stmt.executeUpdate();
        }
    }

    public UserDTO authenticateUser(String id, String password) throws SQLException {
        String query = "SELECT * FROM users WHERE id = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // UserDTO 생성 시 필요한 정보를 적절히 넣어야 합니다.
                // 현재는 예제 코드를 그대로 두었으나, 실제 로직에 맞게 수정해야 합니다.
                return new UserDTO(id, password, query, 0, 0, 0, 0, 0);
            }
        }
        return null; // 사용자 인증 실패 시 null 반환
    }
}
