import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RematchServlet")
public class RematchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // 재매치 요청 카운터 (간단한 상태 유지)
    private static int rematchCount = 0;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String roomIdParam = request.getParameter("roomId");

        // 유효성 검사
        if (roomIdParam != null) {
            synchronized (this) {
                rematchCount++;
                if (rematchCount >= 2) { // 두 명 모두 재매치를 요청한 경우
                    rematchCount = 0; // 카운터 초기화
                    response.getWriter().write("{\"success\":true}");
                } else { // 한 명만 요청한 경우
                    response.getWriter().write("{\"success\":false, \"message\":\"상대방의 응답을 기다리는 중입니다.\"}");
                }
            }
        } else { // 방 ID가 없는 경우
            response.getWriter().write("{\"success\":false, \"message\":\"유효하지 않은 방 ID입니다.\"}");
        }
    }
}
