import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ShopServlet")
public class ShopServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userData = request.getParameter("userData");
        String itemCodeStr = request.getParameter("itemCode");

        if (userData == null || itemCodeStr == null || itemCodeStr.isEmpty()) {
            response.sendRedirect("shop.jsp?userData=" + userData + "&error=Invalid+Selection");
            return;
        }

        int itemCode = Integer.parseInt(itemCodeStr);
        String[] userFields = userData.replace("{", "").replace("}", "").split(",");
        int userCode = 0, userCash = 0;

        for (String field : userFields) {
            String[] keyValue = field.split(":");
            String key = keyValue[0].replace("\"", "").trim();
            String value = keyValue[1].replace("\"", "").trim();

            if (key.equals("userCode")) userCode = Integer.parseInt(value);
            if (key.equals("cash")) userCash = Integer.parseInt(value);
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234");

            // 아이템 가격 가져오기
            String priceQuery = "SELECT price FROM items WHERE item_code = ?";
            stmt = conn.prepareStatement(priceQuery);
            stmt.setInt(1, itemCode);
            rs = stmt.executeQuery();

            if (rs.next()) {
                int price = rs.getInt("price");

                if (userCash < price) {
                    response.sendRedirect("shop.jsp?userData=" + userData + "&error=Insufficient+Funds");
                    return;
                }

                // 구매 처리
                String insertQuery = "INSERT INTO user_items (user_code, item_code) VALUES (?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                insertStmt.setInt(1, userCode);
                insertStmt.setInt(2, itemCode);
                insertStmt.executeUpdate();

                // 캐쉬 차감
                String updateQuery = "UPDATE users SET cash = cash - ? WHERE user_code = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                updateStmt.setInt(1, price);
                updateStmt.setInt(2, userCode);
                updateStmt.executeUpdate();

                response.sendRedirect("shop.jsp?userData=" + userData + "&success=Item+Purchased");
            } else {
                response.sendRedirect("shop.jsp?userData=" + userData + "&error=Item+Not+Found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("shop.jsp?userData=" + userData + "&error=Server+Error");
        } finally {
            if (rs != null) try { rs.close(); } catch (Exception e) { e.printStackTrace(); }
            if (stmt != null) try { stmt.close(); } catch (Exception e) { e.printStackTrace(); }
            if (conn != null) try { conn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
