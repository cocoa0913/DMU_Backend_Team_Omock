import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ChangeIconServlet")
public class ChangeIconServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userData = request.getParameter("userData");
        String iconCodeStr = request.getParameter("iconCode");

        if (userData == null || iconCodeStr == null || iconCodeStr.isEmpty()) {
            response.sendRedirect("myPage.jsp?userData=" + userData + "&error=Invalid+Selection");
            return;
        }

        int iconCode = Integer.parseInt(iconCodeStr);
        int userCode = 0;

        String[] userFields = userData.replace("{", "").replace("}", "").split(",");
        for (String field : userFields) {
            String[] keyValue = field.split(":");
            String key = keyValue[0].replace("\"", "").trim();
            String value = keyValue[1].replace("\"", "").trim();

            if (key.equals("userCode")) userCode = Integer.parseInt(value);
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234");

            String query = "UPDATE users SET icon_code = ? WHERE user_code = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, iconCode);
            stmt.setInt(2, userCode);
            stmt.executeUpdate();

            response.sendRedirect("myPage.jsp?userData=" + userData + "&success=Icon+Updated");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("myPage.jsp?userData=" + userData + "&error=Server+Error");
        } finally {
            if (stmt != null) try { stmt.close(); } catch (Exception e) { e.printStackTrace(); }
            if (conn != null) try { conn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
