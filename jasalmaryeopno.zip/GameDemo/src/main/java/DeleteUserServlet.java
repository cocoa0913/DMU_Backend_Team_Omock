import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String targetUser = request.getParameter("targetUser");

        if (action == null || targetUser == null) {
            response.sendRedirect("adminPanel.jsp?error=Invalid+Request");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234");

            if ("delete".equals(action)) {
                // 사용자 삭제
                String deleteQuery = "DELETE FROM users WHERE username = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery);
                deleteStmt.setString(1, targetUser);
                deleteStmt.executeUpdate();
            } else if ("toggleAdmin".equals(action)) {
                // 관리자 권한 변경
                String toggleQuery = "UPDATE users SET admin_rights = NOT admin_rights WHERE username = ?";
                PreparedStatement toggleStmt = conn.prepareStatement(toggleQuery);
                toggleStmt.setString(1, targetUser);
                toggleStmt.executeUpdate();
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("adminPanel.jsp");
    }
}
