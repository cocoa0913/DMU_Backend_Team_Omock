import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/EnterRoomServlet")
public class EnterRoomServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 세션 검사
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userCode") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String roomIdParam = request.getParameter("roomId");
        int roomId = Integer.parseInt(roomIdParam);
        int userCode = (int) session.getAttribute("userCode");

        try {
            // DB 연결
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234");

            // 방이 존재하는지 확인
            String checkQuery = "SELECT * FROM rooms WHERE room_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, roomId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                // 방이 존재하지 않으면 에러 처리
                request.setAttribute("error", "Room does not exist.");
                request.getRequestDispatcher("findRoom.jsp").forward(request, response);
                return;
            }

            // 방에 참가자 정보 저장
            String insertQuery = "INSERT INTO room_participants (room_id, user_code) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setInt(1, roomId);
            insertStmt.setInt(2, userCode);
            insertStmt.executeUpdate();

            // WebSocket 서버와 동기화
            String websocketMessage = "room_enter:" + rs.getString("room_title");
            GameWebSocket.broadcast(websocketMessage);

            // 방 정보 세션에 저장
            session.setAttribute("roomId", roomId);

            // 게임 페이지로 이동
            response.sendRedirect("game.jsp?roomId=" + roomId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
