import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/game")
public class GameWebSocket {
    private static Set<Session> sessions = ConcurrentHashMap.newKeySet();
    private static List<Room> publicRooms = Collections.synchronizedList(new ArrayList<>());

    @OnOpen
    public void onOpen(Session session) {
        sessions.add(session);
        System.out.println("New connection: " + session.getId());
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        try {
            String[] parts = message.split(":", 2);
            String command = parts[0];

            switch (command) {
                case "room_new":
                    Room newRoom = createRoom(parts[1]);
                    if (newRoom != null) {
                        publicRooms.add(newRoom);
                        broadcastRoomList();
                    }
                    break;

                case "room_list":
                    broadcastRoomList();
                    break;

                case "room_enter":
                    String roomName = parts[1];
                    Room room = findRoomByName(roomName);
                    if (room != null) {
                        room.incrementPlayerCount();
                        broadcastRoomList();
                    } else {
                        session.getBasicRemote().sendText("error:Room not found");
                    }
                    break;

                case "room_remove":
                    removeRoom(parts[1]);
                    break;

                default:
                    System.out.println("Unknown command: " + command);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnClose
    public void onClose(Session session) {
        sessions.remove(session);
        System.out.println("Connection closed: " + session.getId());
    }

    public static void broadcast(String message) {
        for (Session session : sessions) {
            try {
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void broadcastRoomList() {
        synchronized (publicRooms) {
            publicRooms.sort(Comparator.comparing(Room::getCreationTime)); // 생성 시간순 정렬
            StringBuilder json = new StringBuilder("room_list:[");
            for (int i = 0; i < publicRooms.size(); i++) {
                Room room = publicRooms.get(i);
                json.append("{")
                    .append("\"name\":\"").append(room.getName()).append("\",")
                    .append("\"players\":").append(room.getPlayerCount()).append(",")
                    .append("\"status\":\"").append(room.isPrivate() ? "비공개" : "공개").append("\",")
                    .append("\"creationTime\":").append(room.getCreationTime())
                    .append("}");
                if (i < publicRooms.size() - 1) {
                    json.append(",");
                }
            }
            json.append("]");
            broadcast(json.toString());
        }
    }

    private static Room createRoom(String roomData) {
        String[] data = roomData.split(",");
        String roomName = data[0].trim();
        boolean isPrivate = data.length > 1 && !data[1].isEmpty();
        if (roomName == null || roomName.isEmpty()) {
            return null;
        }
        Room newRoom = new Room(roomName);
        if (isPrivate) {
            newRoom.setPrivate(true);
        }
        return newRoom;
    }

    private static Room findRoomByName(String roomName) {
        synchronized (publicRooms) {
            return publicRooms.stream()
                .filter(room -> room.getName().equals(roomName))
                .findFirst()
                .orElse(null);
        }
    }

    public static void removeRoom(String roomName) {
        synchronized (publicRooms) {
            publicRooms.removeIf(room -> room.getName().equals(roomName));
        }
        broadcastRoomList();
    }
}

class Room {
    private String name;
    private int playerCount;
    private boolean isPrivate;
    private long creationTime;

    public Room(String name) {
        this.name = name;
        this.playerCount = 0;
        this.isPrivate = false;
        this.creationTime = System.currentTimeMillis();
    }

    public String getName() {
        return name;
    }

    public int getPlayerCount() {
        return playerCount;
    }

    public void incrementPlayerCount() {
        this.playerCount++;
    }

    public void decrementPlayerCount() {
        if (this.playerCount > 0) {
            this.playerCount--;
        }
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean isPrivate) {
        this.isPrivate = isPrivate;
    }

    public long getCreationTime() {
        return creationTime;
    }
}
