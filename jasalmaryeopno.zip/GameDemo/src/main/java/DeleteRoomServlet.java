import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteRoomServlet")
public class DeleteRoomServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String roomName = request.getParameter("roomName");

        if (roomName != null) {
            try {
                // WebSocket 서버의 방 목록에서 삭제
                GameWebSocket.removeRoom(roomName);

                // JSON 응답
                response.setContentType("application/json");
                response.getWriter().write("{\"success\":true}");
            } catch (Exception e) {
                e.printStackTrace();
                response.setContentType("application/json");
                response.getWriter().write("{\"success\":false, \"message\":\"방 삭제 중 오류가 발생했습니다.\"}");
            }
        } else {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false, \"message\":\"유효하지 않은 방 이름입니다.\"}");
        }
    }
}
