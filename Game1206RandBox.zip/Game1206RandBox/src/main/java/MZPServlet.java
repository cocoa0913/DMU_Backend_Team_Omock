import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MZPServlet")
public class MZPServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 요청과 응답의 인코딩 설정
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String userCode = request.getParameter("userCode");
        String choice = request.getParameter("choice"); // 사용자의 선택
        String nickname = request.getParameter("nickname");
        String level = request.getParameter("level");
        String cash = request.getParameter("cash");

        if (userCode == null || choice == null) {
            response.sendRedirect("MZP.jsp");
            return;
        }

        // 컴퓨터와 사용자의 선택 반복 처리
        String[] options = { "가위", "바위", "보" };
        String computerChoice;
        String result = "draw";

        while ("draw".equals(result)) {
            computerChoice = options[(int) (Math.random() * 3)];

            if (choice.equals(computerChoice)) {
                result = "draw";
            } else if (
                (choice.equals("가위") && computerChoice.equals("보")) ||
                (choice.equals("바위") && computerChoice.equals("가위")) ||
                (choice.equals("보") && computerChoice.equals("바위"))
            ) {
                result = "win";
            } else {
                result = "lose";
            }

            // 게임이 무승부가 아니면 탈출
            if (!"draw".equals(result)) {
                // 데이터베이스 업데이트
                try (
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234");
                    PreparedStatement updateStmt = conn.prepareStatement(
                        "UPDATE users SET win_count = win_count + ?, lose_count = lose_count + ?, " +
                        "experience = experience + ?, cash = cash + ? WHERE user_code = ?"
                    );
                    PreparedStatement levelUpStmt = conn.prepareStatement(
                        "UPDATE users SET experience = experience - 100, level = level + 1 " +
                        "WHERE experience >= 100 AND user_code = ?"
                    );
                ) {
                    if ("win".equals(result)) {
                        updateStmt.setInt(1, 1); // 승리 증가
                        updateStmt.setInt(2, 0); // 패배 증가 없음
                        updateStmt.setInt(3, 30); // 승리 경험치
                        updateStmt.setInt(4, 30); // 승리 캐쉬
                    } else {
                        updateStmt.setInt(1, 0);
                        updateStmt.setInt(2, 1); // 패배 증가
                        updateStmt.setInt(3, 10); // 패배 경험치
                        updateStmt.setInt(4, 10); // 패배 캐쉬
                    }
                    updateStmt.setInt(5, Integer.parseInt(userCode));
                    updateStmt.executeUpdate();

                    levelUpStmt.setInt(1, Integer.parseInt(userCode));
                    levelUpStmt.executeUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // 결과 JSP에 전달
                request.setAttribute("result", result);
                request.setAttribute("computerChoice", computerChoice);
                request.setAttribute("userChoice", choice);
                request.setAttribute("nickname", nickname);
                request.setAttribute("level", level);
                request.setAttribute("cash", cash);
                request.getRequestDispatcher("GameResult.jsp").forward(request, response);
                return;
            }
        }
    }
}
