import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GameServlet")
public class GameServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String userCodeParam = request.getParameter("userCode");
        String level = request.getParameter("level");
        String nickname = request.getParameter("nickname");
        String cashParam = request.getParameter("cash");
        String rewardNumParam = request.getParameter("rewardNum");
        String clickedBox = request.getParameter("clickedBox"); // 박스 번호 전달받기

        // 파라미터 유효성 검사
        if (userCodeParam == null || rewardNumParam == null || userCodeParam.isEmpty() || rewardNumParam.isEmpty() || clickedBox == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters: userCode, rewardNum, clickedBox, or other required fields are missing.");
            return;
        }

        try {
            int userCode = Integer.parseInt(userCodeParam);
            int rewardNum = Integer.parseInt(rewardNumParam);
            int currentCash = Integer.parseInt(cashParam);

            if (currentCash < 100) {
                response.sendRedirect("game.jsp?userCode=" + userCode +
                                      "&level=" + level +
                                      "&nickname=" + nickname +
                                      "&cash=" + currentCash +
                                      "&clickedBox=" + clickedBox +
                                      "&error=잔액부족");
                return;
            }

            // 보상 금액 결정
            int reward = (rewardNum == 1) ? 200 : (rewardNum == 2) ? 50 : 0;

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {
                conn.setAutoCommit(false);

                // 캐쉬 차감
                String deductCashQuery = "UPDATE users SET cash = cash - 100 WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(deductCashQuery)) {
                    stmt.setInt(1, userCode);
                    stmt.executeUpdate();
                }

                // 보상 지급
                String updateCashQuery = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateCashQuery)) {
                    stmt.setInt(1, reward);
                    stmt.setInt(2, userCode);
                    stmt.executeUpdate();
                }

                conn.commit();

                // 업데이트된 cash 반환
                int updatedCash = currentCash - 100 + reward;

                // 보상 결과 JSP로 전달
                response.sendRedirect("game.jsp?userCode=" + userCode +
                                      "&level=" + level +
                                      "&nickname=" + nickname +
                                      "&cash=" + updatedCash +
                                      "&reward=" + reward +
                                      "&clickedBox=" + clickedBox);
            } catch (Exception e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error occurred.");
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format for userCode, cash, or rewardNum.");
        }
    }
}
