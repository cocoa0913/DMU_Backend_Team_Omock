/* 광고배너 */
function imgx(){ // 광고 닫기
	$(".Advertising-form").hide();
}



