import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteFriend")
public class DeleteFriend extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        // 파라미터 읽기
        int userCode = Integer.parseInt(request.getParameter("userCode"));
        int friendCode = Integer.parseInt(request.getParameter("friendCode"));
        String nickname = request.getParameter("nickname");
        String level = request.getParameter("level");
        String cash = request.getParameter("cash");

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/gomoku_db", "root", "password")) {

            // DAO 사용
            UserDAO userDao = new UserDAO(conn);
            boolean success = userDao.deleteFriend(userCode, friendCode);

            if (success) {
                // 삭제 성공 시 리다이렉트
                response.sendRedirect("friends.jsp?userCode=" + userCode 
                        + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash);
            } else {
                // 삭제 실패 시 처리
                response.sendRedirect("friends.jsp?userCode=" + userCode 
                        + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash 
                        + "&error=deleteFailed");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("friends.jsp?userCode=" + userCode 
                    + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash 
                    + "&error=serverError");
        }
    }
}
