package game.BlackJack;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/blackjack")
public class BJControl extends HttpServlet {

    private GameDAO gameDAO;

    @Override
    public void init() throws ServletException {
        gameDAO = new GameDAO();  // DAO 인스턴스 생성
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        if (gameDTO == null || gameDTO.getBetAmount() == 0) {
            // 베팅하지 않은 상태라면 베팅 페이지로 리다이렉트
            response.sendRedirect("Betting.jsp");
            return;
        }

        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        // 게임이 없으면 새로 시작
        if (gameDTO == null) {
            gameDTO = gameDAO.startGame();
            session.setAttribute("game", gameDTO);
        }

        String action = request.getParameter("action");

        if ("bet".equals(action)) {
            // 베팅 금액 설정
            int betAmount = Integer.parseInt(request.getParameter("betAmount"));
            int cash = (int) session.getAttribute("cash");

            // 베팅 금액 유효성 검사
            if (betAmount <= 0 || betAmount > cash) {
                request.setAttribute("errorMessage", "유효하지 않은 베팅 금액입니다.");
                request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
                return;
            }

            // 베팅 금액 설정 및 캐시 차감
            gameDTO.setBetAmount(betAmount);
            cash -= betAmount;
            session.setAttribute("cash", cash);
            session.setAttribute("game", gameDTO);

        } else if ("hit".equals(action)) {
            // 플레이어가 카드를 한 장 더 받음
            gameDTO = gameDAO.hitPlayer(gameDTO);
        } else if ("result".equals(action)) {
            // 딜러가 카드를 뽑음
            gameDTO = gameDAO.dealerTurn(gameDTO);

            // 게임 결과에 따라 캐시 정산
            if (gameDTO.isGameOver()) {
                int betAmount = gameDTO.getBetAmount();
                int cash = (int) session.getAttribute("cash");
                String winner = gameDAO.determineWinner(gameDTO);

                if ("플레이어".equals(winner)) {
                    cash += betAmount * 2; // 승리: 2배 지급
                } else if ("무승부".equals(winner)) {
                    cash += betAmount; // 무승부: 원금 반환
                }
                // 패배 시 캐시는 변경되지 않음

                session.setAttribute("cash", cash);
                request.setAttribute("winner", winner);
            }
        } else if ("restart".equals(action)) {
            // 새 게임 시작
            gameDTO = gameDAO.startGame();
        }

        session.setAttribute("game", gameDTO);
        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }

}

