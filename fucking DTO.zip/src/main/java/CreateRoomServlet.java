import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CreateRoomServlet")
public class CreateRoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 파라미터 가져오기
        String userCodeParam = request.getParameter("userCode");
        String roomTitle = request.getParameter("roomTitle");
        String roomPassword = request.getParameter("roomPassword");

        // 디버깅용 로그 출력
        System.out.println("Received userCode: " + userCodeParam);
        System.out.println("Received roomTitle: " + roomTitle);
        System.out.println("Received roomPassword: " + roomPassword);

        if (userCodeParam == null || roomTitle == null || roomTitle.isEmpty()) {
            response.sendRedirect("createRoom.jsp?error=missingParameters");
            return;
        }

        int userCode;
        try {
            userCode = Integer.parseInt(userCodeParam);
        } catch (NumberFormatException e) {
            response.sendRedirect("createRoom.jsp?error=invalidUserCode");
            return;
        }

        // DTO 생성
        RoomDTO room = new RoomDTO();
        room.setRoomTitle(roomTitle);
        room.setRoomPassword(roomPassword);
        room.setOwnerCode(userCode);
        room.setPrivate(roomPassword != null && !roomPassword.isEmpty());

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {

            // DAO 사용
        	UserDAO userDao = new UserDAO(conn);
            int roomId = userDao.createRoom(room);

            if (roomId > 0) {
                // 방 생성 성공 시 대기실로 이동
                response.sendRedirect("waitingRoom.jsp?roomId=" + roomId + "&userCode=" + userCode);
            } else {
                // 방 생성 실패
                response.sendRedirect("createRoom.jsp?error=creationFailed");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("createRoom.jsp?error=serverError");
        }
    }
}
