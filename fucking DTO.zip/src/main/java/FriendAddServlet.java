import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FriendAddServlet")
public class FriendAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userCodestr = (String) session.getAttribute("userCode");
        String friendNickname = request.getParameter("friendNickname");
        int userCode = 0;

        try {
            userCode = Integer.parseInt(userCodestr);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user code.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {
            // UserDAO 사용
            UserDAO userDao = new UserDAO(conn);
            int friendCode = userDao.getUserCodeByNickname(friendNickname);

            if (friendCode == -1) {
                // 친구를 찾을 수 없는 경우
                String referer = request.getHeader("Referer");
                if (referer != null) {
                    referer = removeErrorParam(referer);
                    response.sendRedirect(referer + "&error=userNotFound");
                }
                return;
            }

            // 입력된 닉네임이 "나"일 경우
            if (userCode == friendCode) {
                String referer = request.getHeader("Referer");
                if (referer != null) {
                    referer = removeErrorParam(referer);
                    response.sendRedirect(referer + "&error=selfFriend");
                }
                return;
            }

            // 친구 관계가 이미 존재하는지 확인
            if (userDao.isAlreadyFriend(userCode, friendCode)) {
                String referer = request.getHeader("Referer");
                if (referer != null) {
                    referer = removeErrorParam(referer);
                    response.sendRedirect(referer + "&error=alreadyFriend");
                }
                return;
            }

            // 친구 추가
            userDao.addFriend(userCode, friendCode);

            String referer = request.getHeader("Referer");
            if (referer != null) {
                referer = removeErrorParam(referer);
                response.sendRedirect(referer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String removeErrorParam(String url) {
        if (url != null && url.contains("&error=")) {
            url = url.replaceAll("(&?error=[^&]+)", "");
            if (url.endsWith("&")) {
                url = url.substring(0, url.length() - 1);
            }
        }
        return url;
    }
}
