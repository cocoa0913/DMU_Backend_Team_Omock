public class RoomDTO {
    private int roomId;
    private String roomTitle;
    private String roomPassword;
    private int ownerCode;
    private boolean isPrivate;

    public RoomDTO() {}

    public RoomDTO(int roomId, String roomTitle, String roomPassword, int ownerCode, boolean isPrivate) {
        this.roomId = roomId;
        this.roomTitle = roomTitle;
        this.roomPassword = roomPassword;
        this.ownerCode = ownerCode;
        this.isPrivate = isPrivate;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public String getRoomTitle() {
        return roomTitle;
    }

    public void setRoomTitle(String roomTitle) {
        this.roomTitle = roomTitle;
    }

    public String getRoomPassword() {
        return roomPassword;
    }

    public void setRoomPassword(String roomPassword) {
        this.roomPassword = roomPassword;
    }

    public int getOwnerCode() {
        return ownerCode;
    }

    public void setOwnerCode(int ownerCode) {
        this.ownerCode = ownerCode;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean isPrivate) {
        this.isPrivate = isPrivate;
    }
}
