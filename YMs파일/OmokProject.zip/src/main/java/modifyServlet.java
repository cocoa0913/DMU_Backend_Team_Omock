import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/modifyServlet")
public class modifyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // 파라미터 읽기
        String userCodeParam = request.getParameter("userCode");
        String newNickname = request.getParameter("newNickname");
        String level = request.getParameter("level");
        String cash = request.getParameter("cash");

        if (userCodeParam == null || userCodeParam.trim().isEmpty() || newNickname == null || newNickname.trim().isEmpty()) {
            response.sendRedirect("modify.jsp?userCode=" + userCodeParam + "&error=닉네임을 입력해주세요");
            return;
        }

        int userCode = Integer.parseInt(userCodeParam);

        // DTO 생성
        UserDTO user = new UserDTO(level, cash, newNickname, userCode, userCode, userCode, userCode, userCode);
        user.setUserCode(userCode);
        user.setNickname(newNickname);

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/gomoku_db?useUnicode=true&characterEncoding=utf8", "root", "password")) {

            // DAO 사용
            UserDAO userDao = new UserDAO(conn);
            boolean isUpdated = userDao.updateNickname(user.getUserCode(), user.getNickname());

            if (isUpdated) {
                // 성공 시 JavaScript 팝업
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().write(
                    "<script>" +
                        "alert('변경 완료! 다시 로그인 해주세요!');" +
                        "window.location.href = 'LogoutServlet';" +
                    "</script>"
                );
                response.sendRedirect("myPage.jsp?userCode=" + userCode + "&nickname=" + newNickname + "&level=" + level + "&cash=" + cash);
            } else {
                response.sendRedirect("modify.jsp?userCode=" + userCode + "&error=사용자 정보를 찾을 수 없습니다");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("modify.jsp?userCode=" + userCode + "&error=DB 처리 중 오류가 발생했습니다");
        }
    }
}
