package game.BlackJack;

import java.util.ArrayList;
import java.util.List;

public class GameDTO {
    private List<CardDTO> playerCards = new ArrayList<>();  // 플레이어 카드 리스트 초기화
    private List<CardDTO> dealerCards = new ArrayList<>();  // 딜러 카드 리스트 초기화
    private int playerScore;  // 플레이어 점수
    private int dealerScore;  // 딜러 점수
    private boolean gameOver;  // 게임 종료 여부
    private boolean dealerTurn;  // 딜러 차례 여부
    private int betAmount;

    // 기본 생성자
    public GameDTO() {
        // 기본 생성자에서 리스트를 초기화하여 null을 방지
        this.playerCards = new ArrayList<>();
        this.dealerCards = new ArrayList<>();
        this.playerScore = 0;
        this.dealerScore = 0;
        this.gameOver = false;
        this.dealerTurn = true; // 딜러 차례는 기본적으로 true
        this.betAmount = 0;
    }

    // GameDTO 생성자 (게임 상태 초기화)
    public GameDTO(List<CardDTO> playerCards, List<CardDTO> dealerCards, int playerScore, int dealerScore, boolean gameOver, boolean dealerTurn, int betAmount) {
        this.playerCards = playerCards != null ? playerCards : new ArrayList<>(); // null 체크 후 초기화
        this.dealerCards = dealerCards != null ? dealerCards : new ArrayList<>(); // null 체크 후 초기화
        this.playerScore = playerScore;
        this.dealerScore = dealerScore;
        this.gameOver = gameOver;
        this.dealerTurn = dealerTurn;
        this.betAmount = betAmount;
    }

    // Getter와 Setter

    public List<CardDTO> getPlayerCards() {
        return playerCards;
    }

    public void setPlayerCards(List<CardDTO> playerCards) {
        this.playerCards = playerCards;
    }

    public List<CardDTO> getDealerCards() {
        return dealerCards;
    }

    public void setDealerCards(List<CardDTO> dealerCards) {
        this.dealerCards = dealerCards != null ? dealerCards : new ArrayList<>();
    }

    public int getPlayerScore() {
        return playerScore;
    }

    public void setPlayerScore(int playerScore) {
        this.playerScore = playerScore;
    }

    public int getDealerScore() {
        return dealerScore;
    }

    public void setDealerScore(int dealerScore) {
        this.dealerScore = dealerScore;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public boolean isDealerTurn() {
        return dealerTurn;
    }

    public void setDealerTurn(boolean dealerTurn) {
        this.dealerTurn = dealerTurn;
    }
    
    public int getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(int betAmount) {
        this.betAmount = betAmount;
    }

}
