package game.BlackJack;

import java.util.List;

public class PlayerDTO {
    private List<CardDTO> playerCards;  // 플레이어 카드 목록
    private int playerScore;            // 플레이어 점수
    private boolean canHit;             // 플레이어가 카드를 받을 수 있는지 여부

    // 생성자
    public PlayerDTO(List<CardDTO> playerCards, int playerScore, boolean canHit) {
        this.playerCards = playerCards;
        this.playerScore = playerScore;
        this.canHit = canHit;
    }

    // Getter 및 Setter
    public List<CardDTO> getPlayerCards() {
        return playerCards;
    }

    public void setPlayerCards(List<CardDTO> playerCards) {
        this.playerCards = playerCards;
    }

    public int getPlayerScore() {
        return playerScore;
    }

    public void setPlayerScore(int playerScore) {
        this.playerScore = playerScore;
    }

    public boolean isCanHit() {
        return canHit;
    }

    public void setCanHit(boolean canHit) {
        this.canHit = canHit;
    }
}
