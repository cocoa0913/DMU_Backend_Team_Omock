public class UserDTO {
    private String id;
    private String password;
    private String nickname;
    private int userCode;
    private int level;
    private int cash;
    private int friendCode;
    private int iconCode;

    public UserDTO(String id, String password, String nickname, int userCode, int level, int cash, int friendCode, int iconCode) {
        this.id = id;
        this.password = password;
        this.nickname = nickname;
        this.userCode = userCode;
        this.level = level;
        this.cash = cash;
        this.friendCode = friendCode;
        this.iconCode = iconCode;
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getUserCode() {
		return userCode;
	}

	public void setUserCode(int userCode) {
		this.userCode = userCode;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getCash() {
		return cash;
	}

	public void setCash(int cash) {
		this.cash = cash;
	}

	public int getFriendCode() {
		return friendCode;
	}

	public void setFriendCode(int friendCode) {
		this.friendCode = friendCode;
	}

	public int getIconCode() {
		return iconCode;
	}

	public void setIconCode(int iconCode) {
		this.iconCode = iconCode;
	}

}
