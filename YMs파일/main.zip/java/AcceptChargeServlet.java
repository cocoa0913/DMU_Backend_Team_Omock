import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AcceptChargeServlet")
public class AcceptChargeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String requestIdParam = request.getParameter("requestId");
        String userCodeParam = request.getParameter("userCode");
        String nickname = request.getParameter("nickname");
        String level = request.getParameter("level");
        String cash = request.getParameter("cash");

        if (requestIdParam == null) {
            response.sendRedirect("adminPanel.jsp?userCode=" + userCodeParam + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash);
            return;
        }

        int requestId = Integer.parseInt(requestIdParam);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "password")) {
            conn.setAutoCommit(false);

            // 해당 요청 정보 가져오기
            String selectQuery = "SELECT user_code, amount FROM charge_requests WHERE request_id = ? AND status='pending'";
            int userCode = 0;
            int amount = 0;
            try (PreparedStatement stmt = conn.prepareStatement(selectQuery)) {
                stmt.setInt(1, requestId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        userCode = rs.getInt("user_code");
                        amount = rs.getInt("amount");
                    } else {
                        // 유효하지 않은 요청
                        conn.rollback();
                        response.sendRedirect("adminPanel.jsp?userCode=" + userCodeParam + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash);
                        return;
                    }
                }
            }

            // 유저 cash 추가
            String updateCashQuery = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateCashQuery)) {
                stmt.setInt(1, amount);
                stmt.setInt(2, userCode);
                stmt.executeUpdate();
            }

            // 요청 삭제 또는 상태 변경
            String deleteQuery = "DELETE FROM charge_requests WHERE request_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {
                stmt.setInt(1, requestId);
                stmt.executeUpdate();
            }

            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 다시 관리자 페이지로
        response.sendRedirect("adminPanel.jsp?userCode=" + userCodeParam + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash);
    }
}
