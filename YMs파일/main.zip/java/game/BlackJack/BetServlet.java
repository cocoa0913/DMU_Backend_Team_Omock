package game.BlackJack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/bet")
public class BetServlet extends HttpServlet {

    private GameDAO gameDAO;

    @Override
    public void init() throws ServletException {
        gameDAO = new GameDAO();  // DAO 인스턴스 생성
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");
        
        // 게임이 없으면 새로 시작
        if (gameDTO == null) {
            gameDTO = gameDAO.startGame();
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        String betAmountStr = request.getParameter("betAmount");  // String으로 베팅 금액 받기
        int betAmount = 0;
        
        // 세션에서 'cash' 값을 가져오기
        Object cashObject = session.getAttribute("cash");

        // cash가 Integer라면 Integer로 캐스팅, 아니면 기본값 0을 사용
        int cash = 0;
        if (cashObject != null) {
            if (cashObject instanceof Integer) {
                cash = (Integer) cashObject;
            } else {
                try {
                    // 만약 String으로 저장된 값이 있다면 이를 정수로 변환
                    cash = Integer.parseInt(cashObject.toString());
                } catch (NumberFormatException e) {
                    // 예외가 발생하면 0으로 설정 (또는 적절한 예외 처리)
                    cash = 0;
                }
            }
        }
        
        try {
            // betAmountStr이 숫자일 때만 Integer로 변환
            betAmount = Integer.parseInt(betAmountStr);
            
        } catch (NumberFormatException e) {
            // 숫자가 아닌 값이 들어온 경우 예외 처리
            request.setAttribute("errorMessage", "유효하지 않은 베팅 금액입니다.");
            String contextPath = request.getContextPath();
            request.setAttribute("contextPath", contextPath);
            request.getRequestDispatcher("Game/GameBindex.jsp").forward(request, response);
            return;
        }

        

        // 베팅 금액 유효성 검사
        if (betAmount <= 0 || betAmount > cash) {
            request.setAttribute("errorMessage", "유효하지 않은 베팅 금액입니다.");
            String contextPath = request.getContextPath();
            request.setAttribute("contextPath", contextPath);
            request.getRequestDispatcher("Game/GameBindex.jsp").forward(request, response);
            return;
        }

        // 베팅 금액 설정 및 캐시 차감
        gameDTO.setBetAmount(betAmount);
        cash -= betAmount;
        session.setAttribute("betAmount", betAmount);
        session.setAttribute("cash", cash);  // 세션에서 캐시 업데이트
        session.setAttribute("game", gameDTO);  // 게임 정보 다시 저장

        // 베팅이 완료되면, 게임 진행 페이지로 리다이렉트
        response.sendRedirect("blackjack");
    }
}
