package game.BlackJack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
    private List<CardDTO> cards;

    public Deck() {
        cards = new ArrayList<>();
        String[] suits = {"스페이드", "하트", "다이아", "클로버"};
        String[] ranks = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
        
        for (String suit : suits) {			// 문양별로 13개의 숫자를 조합해 총 52장의 카드를 생성
            for (String rank : ranks) {
                cards.add(new CardDTO(suit, rank));
            }
        }
        Collections.shuffle(cards); // 52장의 카드를 무작위로 섞어줌.
    }

    public CardDTO draw() {
        return cards.remove(0);	// 덱 맨 위에서 카드 한장을 뽑아 반환하며 카드덱에서 삭제됨.
    }
    
    public int size() {
        return cards.size();
    }
}
