package game.BlackJack;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

public class GameDAO {

    private Deck deck = new Deck(); // 덱 생성
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/gomoku_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";
    
    public void checkAndResetDeck() {
        if (deck.size() == 0) {
            System.out.println("덱을 초기화합니다.");
            deck = new Deck(); // 덱 새로 생성
        }
    }
    
    public GameDTO startGame() {
        List<CardDTO> playerCards = new ArrayList<>();
        List<CardDTO> dealerCards = new ArrayList<>();
        
        // 카드 두 장씩 나눠주기
        playerCards.add(deck.draw());
        playerCards.add(deck.draw());
        dealerCards.add(deck.draw());
        
        // 초기 점수 계산
        int playerScore = calculateScore(playerCards);
        int dealerScore = calculateScore(dealerCards);
        
        GameDTO gameDTO = new GameDTO(playerCards, dealerCards, playerScore, dealerScore, false, true, 0);
        return gameDTO;
    }

    public GameDTO hitPlayer(GameDTO gameDTO) {
        List<CardDTO> playerCards = new ArrayList<>(gameDTO.getPlayerCards());
        playerCards.add(deck.draw());
        
        int newPlayerScore = calculateScore(playerCards);
        gameDTO.setPlayerCards(playerCards);
        gameDTO.setPlayerScore(newPlayerScore);

        if (newPlayerScore > 21) {
            gameDTO.setGameOver(true);
        }

        return gameDTO;
    }

    public GameDTO dealerTurn(GameDTO gameDTO) {
        while (gameDTO.getDealerScore() < 17) {
            gameDTO.getDealerCards().add(deck.draw());
            int newDealerScore = calculateScore(gameDTO.getDealerCards());
            gameDTO.setDealerScore(newDealerScore);
        }
        gameDTO.setGameOver(true);
        return gameDTO;
    }

    private int calculateScore(List<CardDTO> cards) {
        int score = 0;
        int aceCount = 0;

        for (CardDTO card : cards) {
            int value = card.getValue();
            if (value == 1) {
                aceCount++;
                value = 11;
            }
            score += value;
        }

        while (score > 21 && aceCount > 0) {
            score -= 10;
            aceCount--;
        }

        return score;
    }
    
    public String determineWinner(GameDTO gameDTO) {
        int playerScore = gameDTO.getPlayerScore();
        int dealerScore = gameDTO.getDealerScore();

        if (playerScore == 21 && gameDTO.getPlayerCards().size() == 2) {
            return "플레이어 승리 (블랙잭)";
        }
        
        if (playerScore > 21) {
            return "딜러 승리 (플레이어 21 초과 패)";
        }
        
        if (dealerScore > 21) {
            return "플레이어 승리 (딜러 21 초과 패)";
        }

        if (playerScore > dealerScore) {
            return "플레이어 승리";
        } else if (playerScore < dealerScore) {
            return "딜러 승리";
        } else {
            return "무승부";
        }
    }
    
    public int saveGameResult(GameDTO gameDTO, String winner, int userCode, int cash, HttpSession session) {
        String sqlCashUpdate = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
        String sqlLoseCountUpdate = "UPDATE users SET lose_count = lose_count + ? WHERE user_code = ?";
        String sqlWinCountUpdate = "UPDATE users SET win_count = win_count + ? WHERE user_code = ?";
        String sqlExpLevelUpdate = "UPDATE users SET experience = ?, level = ? WHERE user_code = ?";

        int betAmount = (int) session.getAttribute("betAmount");
        int cashChange = 0;
        int winCountChange = 0;
        int loseCountChange = betAmount; // 항상 betAmount만큼 증가
        int currentExperience = 0;
        int currentLevel = 0;

        if ("플레이어 승리 (블랙잭)".equals(winner)) {
            cashChange = betAmount * 2;
            winCountChange = betAmount * 2;
        } else if ("플레이어 승리 (딜러 21 초과 패)".equals(winner) || "플레이어 승리".equals(winner)) {
            cashChange = betAmount;
            winCountChange = betAmount * 2;
        } else if ("무승부".equals(winner)) {
            cashChange = 0;
            winCountChange = betAmount;
        } else if ("딜러 승리 (플레이어 21 초과 패)".equals(winner) || "딜러 승리".equals(winner)) {
            cashChange = -betAmount;
            winCountChange = 0;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String fetchExpLevelQuery = "SELECT experience, level FROM users WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(fetchExpLevelQuery)) {
                    stmt.setInt(1, userCode);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            currentExperience = rs.getInt("experience");
                            currentLevel = rs.getInt("level");
                        }
                    }
                }

                currentExperience += 10;
                if (currentExperience >= 100) {
                    currentExperience -= 100;
                    currentLevel += 1;
                }

                try (PreparedStatement stmt = conn.prepareStatement(sqlCashUpdate)) {
                    stmt.setInt(1, cashChange);
                    stmt.setInt(2, userCode);
                    stmt.executeUpdate();
                }

                try (PreparedStatement stmt = conn.prepareStatement(sqlLoseCountUpdate)) {
                    stmt.setInt(1, loseCountChange);
                    stmt.setInt(2, userCode);
                    stmt.executeUpdate();
                }

                if (winCountChange > 0) {
                    try (PreparedStatement stmt = conn.prepareStatement(sqlWinCountUpdate)) {
                        stmt.setInt(1, winCountChange);
                        stmt.setInt(2, userCode);
                        stmt.executeUpdate();
                    }
                }

                try (PreparedStatement stmt = conn.prepareStatement(sqlExpLevelUpdate)) {
                    stmt.setInt(1, currentExperience);
                    stmt.setInt(2, currentLevel);
                    stmt.setInt(3, userCode);
                    stmt.executeUpdate();
                }

                System.out.println("게임 결과와 사용자 정보가 성공적으로 저장되었습니다.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return cash + cashChange;
    }
    
    public int cashReroading(int userCode) {
        String sql = "SELECT cash FROM users WHERE user_code = ?";
        int cash = -1;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, userCode);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        cash = rs.getInt("cash");
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return cash;
    }
}
