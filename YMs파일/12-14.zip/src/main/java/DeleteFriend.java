import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteFriend")
public class DeleteFriend extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gomoku_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        try {
            // 파라미터 읽기
            String userCodeParam = request.getParameter("userCode");
            String friendCodeParam = request.getParameter("friendCode");
            String nickname = request.getParameter("nickname");
            String level = request.getParameter("level");
            String cash = request.getParameter("cash");

            if (userCodeParam == null || friendCodeParam == null || nickname == null || level == null || cash == null) {
                response.sendRedirect("friends.jsp?error=missingParameters");
                return;
            }

            int userCode = Integer.parseInt(userCodeParam);
            int friendCode = Integer.parseInt(friendCodeParam);

            // 데이터베이스 연결 및 삭제 쿼리 실행
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String deleteQuery = "DELETE FROM friends WHERE user_code = ? AND friend_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {
                    stmt.setInt(1, userCode);
                    stmt.setInt(2, friendCode);

                    int rowsAffected = stmt.executeUpdate();
                    if (rowsAffected > 0) {
                        // 삭제 성공 시 리다이렉트
                        response.sendRedirect("friends.jsp?userCode=" + userCode
                                + "&nickname=" + nickname
                                + "&level=" + level
                                + "&cash=" + cash);
                    } else {
                        // 삭제 실패 처리
                        response.sendRedirect("friends.jsp?userCode=" + userCode
                                + "&nickname=" + nickname
                                + "&level=" + level
                                + "&cash=" + cash
                                + "&error=deleteFailed");
                    }
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect("friends.jsp?error=invalidParameters");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("friends.jsp?error=serverError");
        }
    }
}
