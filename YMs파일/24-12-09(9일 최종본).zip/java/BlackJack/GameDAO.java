package game.BlackJack;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.http.HttpSession;

public class GameDAO {
	
    private Deck deck = new Deck(); // 덱 생성
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/gomoku_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";
    
    public void checkAndResetDeck() {
        if (deck.size() == 0) {
            System.out.println("덱을 초기화합니다.");
            deck = new Deck(); // 덱 새로 생성
        }
    }
    
    public GameDTO startGame() {
        List<CardDTO> playerCards = new ArrayList<>();
        List<CardDTO> dealerCards = new ArrayList<>();
        
        // 카드 두 장씩 나눠주기
        playerCards.add(deck.draw());
        playerCards.add(deck.draw());
        dealerCards.add(deck.draw());
        
        // 초기 점수 계산
        int playerScore = calculateScore(playerCards);
        int dealerScore = calculateScore(dealerCards);
        
        GameDTO gameDTO = new GameDTO(playerCards, dealerCards, playerScore, dealerScore, false, true, 0);
        return gameDTO;
    }

    public GameDTO hitPlayer(GameDTO gameDTO) {
        // 기존 카드를 그대로 두고, 새 카드만 추가하도록 처리
        List<CardDTO> playerCards = new ArrayList<>(gameDTO.getPlayerCards()); // 기존 카드를 복사
        playerCards.add(deck.draw()); // 새 카드 한 장 추가
        
        // 새로운 점수 계산
        int newPlayerScore = calculateScore(playerCards);
        gameDTO.setPlayerCards(playerCards); // 새로운 카드를 가진 리스트로 업데이트
        gameDTO.setPlayerScore(newPlayerScore); // 점수 업데이트

        // 플레이어 점수가 21을 넘으면 게임 종료
        if (newPlayerScore > 21) {
            gameDTO.setGameOver(true);
        }

        return gameDTO;
    }

    public GameDTO dealerTurn(GameDTO gameDTO) {
        // 딜러의 턴: 딜러 점수가 16 미만이면 계속 카드를 받음
        while (gameDTO.getDealerScore() < 17) {
            gameDTO.getDealerCards().add(deck.draw());
            int newDealerScore = calculateScore(gameDTO.getDealerCards());
            gameDTO.setDealerScore(newDealerScore);
        }
        
        // 딜러가 카드를 더 이상 받지 않으면 게임 종료
        gameDTO.setGameOver(true);
        return gameDTO;
    }

    private int calculateScore(List<CardDTO> cards) {
        int score = 0;
        int aceCount = 0;

        // 카드의 점수 합 계산
        for (CardDTO card : cards) {
            int value = card.getValue();
            if (value == 1) {
                aceCount++;
                value = 11;
            }
            score += value;
        }

        // ACE 카드가 있을 경우 11을 1로 변경
        while (score > 21 && aceCount > 0) {
            score -= 10;
            aceCount--;
        }

        return score;
    }
    
    public String determineWinner(GameDTO gameDTO) {
        int playerScore = gameDTO.getPlayerScore();
        int dealerScore = gameDTO.getDealerScore();

        // 1) 블랙잭 승리 - 플레이어가 처음 2장으로 21을 만들었을 경우
        if (playerScore == 21 && gameDTO.getPlayerCards().size() == 2) {
            return "플레이어 승리 (블랙잭)";
        }
        
        if (playerScore > 21 && gameDTO.getPlayerCards().size() == 2) {
            return "딜러 승리 (플레이어 21 초과 패)";
        }

        // 2) 플레이어 21 초과 시 패배
        if (playerScore > 21) {
        	return "딜러 승리 (플레이어 21 초과 패)";
        }
        
        if (dealerScore > 21) {
        	return "플레이어 승리 (딜러 21 초과 패)";
        }

        // 3) 플레이어와 딜러 둘 다 21 이하일 경우 카드 합이 더 높은 쪽이 승리
        if (playerScore <= 21 && dealerScore <= 21) {
            if (playerScore > dealerScore) {
                return "플레이어 승리";
            } else if (playerScore < dealerScore) {
                return "딜러 승리";
            } else {
                return "무승부";
            }
        }

        return "무승부";  // 예외 처리: 모든 조건에서 무승부는 기본적으로 처리되지 않음
    }
    
    public int saveGameResult(GameDTO gameDTO, String winner, int userCode, int cash, HttpSession session) {
    	// DB에서 사용자 정보를 가져와서 캐시를 업데이트
    	String sql = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
    	
    	int betAmount = (int) session.getAttribute("betAmount");
    	System.out.println(betAmount + "베팅");
        int cashChange = 0;

        if ("플레이어 승리 (블랙잭)".equals(winner)) {
            // 플레이어 승리: 베팅 금액 3배 지급(블랙잭)
            cashChange = betAmount * 2;
        } else if("플레이어 승리 (딜러 21 초과 패)".equals(winner) || "플레이어 승리".equals(winner)) {
        	// 플레이어 승리: 베팅 금액 2배 지급
        	cashChange = betAmount * 1;
        } else if ("무승부".equals(winner)) {
            // 무승부: 원금 반환
            cashChange = betAmount * 0; 
        } else if ("딜러 승리 (플레이어 21 초과 패)".equals(winner) || "딜러 승리".equals(winner)){
            // 딜러 승리: 캐시 변동 없음
            cashChange = betAmount * -1;
        }
    	
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            	PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, cashChange);  // 캐시 변화 금액
                stmt.setInt(2, userCode);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("게임 결과와 캐시가 성공적으로 저장되었습니다.");
                }
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버를 찾을 수 없습니다.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL 오류 발생");
            e.printStackTrace();
        }
        
        return cash;  // 갱신된 캐시 반환
    }
    
    public int cashReroading(int userCode) {
    	
    	String sql = "SELECT cash FROM users WHERE user_code = ?";
    	int cash = -1;
    	
    	try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            	PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, userCode);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        cash = rs.getInt("cash");
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            System.out.println("cashReroading JDBC 드라이버를 찾을 수 없습니다.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("cashReroading SQL 오류 발생");
            e.printStackTrace();
        }
    	
    	return cash;
    }
}
