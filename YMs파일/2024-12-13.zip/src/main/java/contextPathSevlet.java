
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/contextPath")
public class contextPathSevlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // contextPath 설정
        String contextPath = request.getContextPath();
        request.setAttribute("contextPath", contextPath);  // contextPath를 JSP에서 사용할 수 있도록 전달

        // JSP로 포워드
        RequestDispatcher dispatcher = request.getRequestDispatcher("Game/game.jsp");
        dispatcher.forward(request, response);
    }
}
