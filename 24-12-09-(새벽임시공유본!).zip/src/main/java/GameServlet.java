import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;

@WebServlet("/GameServlet")
public class GameServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String userCodeParam = request.getParameter("userCode");
        String levelParam = request.getParameter("level");
        String nickname = request.getParameter("nickname");
        String cashParam = request.getParameter("cash");
        String rewardNumParam = request.getParameter("rewardNum");
        String clickedBox = request.getParameter("clickedBox");
        String experienceParam = request.getParameter("experience");

        if (userCodeParam == null || rewardNumParam == null || userCodeParam.isEmpty() || rewardNumParam.isEmpty() || clickedBox == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
            return;
        }

        try {
            int userCode = Integer.parseInt(userCodeParam);
            int rewardNum = Integer.parseInt(rewardNumParam);
            int currentCash = Integer.parseInt(cashParam);

            int currentLevel = 0;
            int currentExperience = 0;

            try {
                currentLevel = Integer.parseInt(levelParam);
            } catch (NumberFormatException e) {
                currentLevel = 0;
            }

            try {
                currentExperience = Integer.parseInt(experienceParam);
            } catch (NumberFormatException e) {
                currentExperience = 0;
            }

            if (currentCash < 100) {
                response.sendRedirect("game.jsp?userCode=" + userCode +
                                      "&level=" + currentLevel +
                                      "&nickname=" + nickname +
                                      "&cash=" + currentCash +
                                      "&experience=" + currentExperience +
                                      "&clickedBox=" + clickedBox +
                                      "&error=잔액부족");
                return;
            }

            // 보상 금액 결정
            int reward = (rewardNum == 1) ? 200 : (rewardNum == 2) ? 50 : 0;

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "password")) {
                conn.setAutoCommit(false);

                // 캐쉬 100 차감
                String deductCashQuery = "UPDATE users SET cash = cash - 100 WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(deductCashQuery)) {
                    stmt.setInt(1, userCode);
                    stmt.executeUpdate();
                }

                // 보상 지급
                String updateCashQuery = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateCashQuery)) {
                    stmt.setInt(1, reward);
                    stmt.setInt(2, userCode);
                    stmt.executeUpdate();
                }

                // 보상만큼 win_count 증가
                String updateWinCountQuery = "UPDATE users SET win_count = win_count + ? WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateWinCountQuery)) {
                    stmt.setInt(1, reward);
                    stmt.setInt(2, userCode);
                    stmt.executeUpdate();
                }

                // lose_count 100 증가 (cash 100 사용 시)
                String updateLoseCountQuery = "UPDATE users SET lose_count = lose_count + 100 WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateLoseCountQuery)) {
                    stmt.setInt(1, userCode);
                    stmt.executeUpdate();
                }

                // 경험치 +10
                currentExperience += 10;
                // 레벨업 체크
                if (currentExperience >= 100) {
                    currentExperience -= 100;
                    currentLevel += 1;
                }

                // DB에 experience, level 업데이트
                String updateExpLevelQuery = "UPDATE users SET experience = ?, level = ? WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateExpLevelQuery)) {
                    stmt.setInt(1, currentExperience);
                    stmt.setInt(2, currentLevel);
                    stmt.setInt(3, userCode);
                    stmt.executeUpdate();
                }

                conn.commit();

                // 업데이트된 cash 재계산
                int updatedCash = currentCash - 100 + reward;

                // JSP로 리다이렉트 (경험치, 레벨 포함)
                response.sendRedirect("game.jsp?userCode=" + userCode +
                                      "&level=" + currentLevel +
                                      "&nickname=" + nickname +
                                      "&cash=" + updatedCash +
                                      "&experience=" + currentExperience +
                                      "&reward=" + reward +
                                      "&clickedBox=" + clickedBox);

            } catch (Exception e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error occurred.");
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format.");
        }
    }
}
