import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/GameServlet2")
public class GameServlet2 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String userCodeParam = request.getParameter("userCode");
        String level = request.getParameter("level");
        String nickname = request.getParameter("nickname");
        String cashParam = request.getParameter("cash");

        if (userCodeParam == null || level == null || nickname == null || cashParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters");
            return;
        }

        int userCode;
        int currentCash;
        try {
            userCode = Integer.parseInt(userCodeParam);
            currentCash = Integer.parseInt(cashParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format.");
            return;
        }

        if (!"play".equals(action)) {
            response.sendRedirect("game2.jsp?userCode=" + userCode + "&level=" + level + "&nickname=" + nickname + "&cash=" + currentCash);
            return;
        }

        // 슬롯머신 플레이 로직
        // 1. 플레이 시 500 캐쉬 소모
        if (currentCash < 500) {
            // 캐쉬 부족
            response.sendRedirect("game2.jsp?userCode=" + userCode + "&level=" + level + "&nickname=" + nickname + "&cash=" + currentCash + "&error=잔액부족");
            return;
        }

        currentCash -= 500; // 500 차감

        // lose_count += 500
        // 슬롯머신 결과 3자리 랜덤숫자 (0~9)
        int[] slots = new int[3];
        for (int i = 0; i < 3; i++) {
            slots[i] = (int)(Math.random() * 10);
        }

        // 결과 문자열 생성
        StringBuilder sb = new StringBuilder();
        for (int num : slots) {
            sb.append(num);
        }

        String resultStr = sb.toString();
        int baseValue = Integer.parseInt(resultStr); // 예: 347 → 347캐쉬

        // 보상 계산
        // 같은 숫자 3개: 10배, 다만 (7,7,7)일 경우 100배
        int reward = baseValue;
        if (slots[0] == slots[1] && slots[1] == slots[2]) {
            // 3개 동일
            if (slots[0] == 7) {
                reward = baseValue * 100; 
            } else {
                reward = baseValue * 10;
            }
        }

        // DB 업데이트: cash += reward, lose_count += 500, win_count += reward
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "password")) {
            conn.setAutoCommit(false);

            // lose_count 증가
            String loseQuery = "UPDATE users SET lose_count = lose_count + 500 WHERE user_code = ?";
            try (PreparedStatement stmt = conn.prepareStatement(loseQuery)) {
                stmt.setInt(1, userCode);
                stmt.executeUpdate();
            }

            // win_count 증가
            String winQuery = "UPDATE users SET win_count = win_count + ? WHERE user_code = ?";
            try (PreparedStatement stmt = conn.prepareStatement(winQuery)) {
                stmt.setInt(1, reward);
                stmt.setInt(2, userCode);
                stmt.executeUpdate();
            }

            // cash 추가
            String cashQuery = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
            try (PreparedStatement stmt = conn.prepareStatement(cashQuery)) {
                stmt.setInt(1, reward);
                stmt.setInt(2, userCode);
                stmt.executeUpdate();
            }

            // 최종적으로 업데이트된 cash 재조회
            String selectQuery = "SELECT cash FROM users WHERE user_code = ?";
            int updatedCash = currentCash;
            try (PreparedStatement stmt = conn.prepareStatement(selectQuery)) {
                stmt.setInt(1, userCode);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        updatedCash = rs.getInt("cash");
                    }
                }
            }

            conn.commit();

            // 결과 페이지로 리다이렉트
            response.sendRedirect("game2.jsp?userCode=" + userCode 
                                    + "&level=" + level 
                                    + "&nickname=" + nickname 
                                    + "&cash=" + updatedCash 
                                    + "&result=" + resultStr
                                    + "&reward=" + reward);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error occurred.");
        }
    }
}
