import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String nickname = request.getParameter("nickname");

        UserDTO user = new UserDTO(id, password, nickname, 0, 0, 0, 0, 0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {
            UserDAO userDao = new UserDAO(conn);

            boolean idExists = userDao.isIdExists(user.getId());
            boolean nicknameExists = userDao.isNicknameExists(user.getNickname());

            if (idExists && nicknameExists) {
                request.setAttribute("error", "ID와 닉네임이 모두 이미 존재합니다.");
            } else if (idExists) {
                request.setAttribute("error", "이미 존재하는 ID입니다.");
            } else if (nicknameExists) {
                request.setAttribute("error", "이미 존재하는 닉네임입니다.");
            } else {
                int userCode = userDao.addUser(user);
                if (userCode != -1) {
                    userDao.addDefaultItem(userCode);
                }
                response.sendRedirect("login.jsp");
                return;
            }

            request.setAttribute("id", id);
            request.setAttribute("nickname", nickname);
            request.getRequestDispatcher("signup.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp");
        }
    }
}
