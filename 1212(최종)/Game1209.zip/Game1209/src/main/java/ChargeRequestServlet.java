import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ChargeRequestServlet")
public class ChargeRequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String userCodeParam = request.getParameter("userCode");
        String nickname = request.getParameter("nickname");
        String level = request.getParameter("level");
        String cash = request.getParameter("cash");
        String depositorName = request.getParameter("depositor_name");
        String amountParam = request.getParameter("amount");

        if(userCodeParam == null || amountParam == null || depositorName == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userCode = Integer.parseInt(userCodeParam);
        int amount = Integer.parseInt(amountParam);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {
            String insertQuery = "INSERT INTO charge_requests(user_code, depositor_name, amount) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                stmt.setInt(1, userCode);
                stmt.setString(2, depositorName);
                stmt.setInt(3, amount);
                stmt.executeUpdate();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        // 신청 완료 후 다시 main.jsp로 리다이렉트
        response.sendRedirect("main.jsp?userCode=" + userCodeParam + "&nickname=" + nickname + "&level=" + level + "&cash=" + cash);
    }
}
