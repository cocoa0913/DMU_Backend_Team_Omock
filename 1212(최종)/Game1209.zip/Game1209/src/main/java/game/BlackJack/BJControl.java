package game.BlackJack;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/blackjack")
public class BJControl extends HttpServlet {

    private GameDAO gameDAO;

    @Override
    public void init() throws ServletException {
        gameDAO = new GameDAO();  // DAO 인스턴스 생성
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 세션에서 gameDTO 가져오기
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        // 게임이 종료되었거나, gameDTO가 없다면 게임을 새로 시작
        if (gameDTO == null || gameDTO.isGameOver()) {
            gameDTO = gameDAO.startGame();  // 새 게임 시작
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 세션에서 gameDTO 가져오기
        HttpSession session = request.getSession();
        GameDTO gameDTO = (GameDTO) session.getAttribute("game");

        // 게임이 없으면 새로 시작
        if (gameDTO == null) {
            gameDTO = gameDAO.startGame();
            session.setAttribute("game", gameDTO);  // 세션에 저장
        }

        String action = request.getParameter("action");

        if ("hit".equals(action)) {
            // 플레이어가 카드를 한 장 더 받음
        	gameDAO.checkAndResetDeck();
            gameDTO = gameDAO.hitPlayer(gameDTO);
        } else if ("result".equals(action)) {
            // 딜러가 카드를 뽑음
            gameDTO = gameDAO.dealerTurn(gameDTO);

            // 게임 결과에 따라 캐시 정산
            if (gameDTO.isGameOver()) {
            	
                int betAmount = gameDTO.getBetAmount();  // 베팅 금액
                int cash = (int) session.getAttribute("cash");  // 현재 캐시
                // 승패 판별
                String winner = gameDAO.determineWinner(gameDTO);
                
                Object userCodeObject = session.getAttribute("userCode");
            	
            	int userCode = 0;
                if (userCodeObject != null) {
                    if (userCodeObject instanceof Integer) {
                        userCode = (Integer) userCodeObject;
                    } else {
                        try {
                            // 만약 String으로 저장된 값이 있다면 이를 정수로 변환
                            userCode = Integer.parseInt(userCodeObject.toString());
                        } catch (NumberFormatException e) {
                            // 예외가 발생하면 0으로 설정 (또는 적절한 예외 처리)
                            userCode = 0;
                        }
                    }
                }
                String nickname = (String) session.getAttribute("nickname");
                String level = (String) session.getAttribute("level");

                gameDAO.saveGameResult(gameDTO, winner, userCode, cash, session);
                
                cash = gameDAO.cashReroading(userCode);
                System.out.println(cash + "마지막 반환값");
                request.setAttribute("cash", cash);
                request.setAttribute("winner", winner);
                // 게임 종료 후 베팅 페이지로 리다이렉트
                request.getRequestDispatcher("/GameBJwinner.jsp").forward(request, response);
                return;
            }
        }
        session.setAttribute("game", gameDTO);  // 세션에 저장
        
        ServletContext context = getServletContext();
        request.getRequestDispatcher("/GameBJack.jsp").forward(request, response);
    }
}

