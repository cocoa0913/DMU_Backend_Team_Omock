import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CashAdjustServlet")
public class CashAdjustServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String targetUserCodeParam = request.getParameter("targetUserCode");
        String cashAdjustmentParam = request.getParameter("cashAdjustment");

        String userCodeParam = request.getParameter("userCode");
        String nickname = request.getParameter("nickname");
        String level = request.getParameter("level");

        if (targetUserCodeParam == null || targetUserCodeParam.isEmpty() || cashAdjustmentParam == null || cashAdjustmentParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
            return;
        }

        try {
            int targetUserCode = Integer.parseInt(targetUserCodeParam);
            int cashAdjustment = Integer.parseInt(cashAdjustmentParam); // +100, -50 등 정수 변환

            int updatedCash = 0; // 업데이트 후 캐시 값 저장용

            // DB 연결 및 업데이트 처리
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gomoku_db", "root", "1234")) {
                // 캐시 업데이트 쿼리
                String updateCashQuery = "UPDATE users SET cash = cash + ? WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateCashQuery)) {
                    stmt.setInt(1, cashAdjustment);
                    stmt.setInt(2, targetUserCode);
                    stmt.executeUpdate();
                }

                // 업데이트된 캐시 값 조회
                String selectCashQuery = "SELECT cash FROM users WHERE user_code = ?";
                try (PreparedStatement stmt = conn.prepareStatement(selectCashQuery)) {
                    stmt.setInt(1, targetUserCode);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            updatedCash = rs.getInt("cash"); // 업데이트된 캐시 값 가져오기
                        }
                    }
                }
            }

            // 리다이렉트 시 업데이트된 캐시 값을 포함
            response.sendRedirect("adminPanel.jsp?userCode=" + userCodeParam +
                    "&nickname=" + nickname +
                    "&level=" + level +
                    "&cash=" + updatedCash);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number format.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error occurred.");
        }
    }
}
